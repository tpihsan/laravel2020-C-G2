<footer>
    <div class="container-fluid">
        <div>© 2020 Primex - <a href="http://laborasyon.com" target="_blank">Laborasyon</a></div>
        <div>
            <nav class="nav">
                <a href="https://themeforest.net/licenses/standard" class="nav-link">Licenses</a>
                <a href="#" class="nav-link">Change Log</a>
                <a href="#" class="nav-link">Get Help</a>
            </nav>
        </div>
    </div>
</footer>
