@extends('layouts.app')
@section('content')
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="#">Management Product</a>
        </li>
        <li class="breadcrumb-item active">
            <a href="#">Customer</a>
        </li>
    </ol>
</nav>
<div class="card">
    <div class="card-body">
        <h2 class="card-title">Buat Customer</h2>
        <form action="{{ route('paket.store') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="">Nama Customer</label>
                <input type="text" name="nm_customer" required
                    class="form-control {{ $errors->has('nm_customer') ? 'is-invalid':'' }}" autofocus>
                <p class="text-danger">{{ $errors->first('nm_customer') }}</p>
            </div>
            <div class="form-group">
                <label for="">Alamat</label>
                <input type="text" name="alamat" required
                    class="form-control {{ $errors->has('alamat') ? 'is-invalid':'' }}" min="1">
                <p class="text-danger">{{ $errors->first('alamat') }}</p>
            </div>
            <div class="form-group">
                <label for="">No Telp</label>
                <input type="text" name="notelp" required
                    class="form-control {{ $errors->has('notelp') ? 'is-invalid':'' }}" min="1">
                <p class="text-danger">{{ $errors->first('notelp') }}</p>
            </div>
            
            <div class="form-group">
                <button class="btn btn-primary btn-sm" style="float: right">
                    <i class="fa fa-send"></i> Save
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
