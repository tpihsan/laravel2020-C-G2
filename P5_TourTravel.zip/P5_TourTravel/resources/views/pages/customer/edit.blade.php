@extends('layouts.app')
@section('content')
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="#">Management Product</a>
        </li>
        <li class="breadcrumb-item active">
            <a href="#">Customer</a>
        </li>
    </ol>
</nav>
<div class="card">
    <div class="card-body">
        <h2 class="card-title">Edit Customer</h2>
        <form action="{{ route('customer.update', $customers->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="_method" value="PUT">
            <div class="form-group">
                <label for="">Nama Customer</label>
                <input type="text" name="nm_customer" required 
                    value="{{ $customers->nm_customer }}"
                    class="form-control {{ $errors->has('nm_customer') ? 'is-invalid':'' }}">
                <p class="text-danger">{{ $errors->first('nm_customer') }}</p>
            </div>
            <div class="form-group">
                <label for="">Alamat</label>
                <input type="text" name="alamat" required 
                    value="{{ $customers->alamat }}"
                    class="form-control {{ $errors->has('alamat') ? 'is-invalid':'' }}">
                <p class="text-danger">{{ $errors->first('alamat') }}</p>
            </div>
            <div class="form-group">
                <label for="">No Telp</label>
                <input type="text" name="notelp" required 
                    value="{{ $customers->notelp }}"
                    class="form-control {{ $errors->has('notelp') ? 'is-invalid':'' }}">
                <p class="text-danger">{{ $errors->first('notelp') }}</p>
            </div>
            
            <div class="form-group">
                <button class="btn btn-info btn-sm">
                    <i class="fa fa-refresh"></i> Update
                </button>
            </div>
        </form>
    </div>
</div>

@endsection