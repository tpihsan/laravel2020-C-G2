@extends('layouts.app')
@section('content')
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="#">Management Product</a>
        </li>
        <li class="breadcrumb-item active">
            <a href="#">Paket</a>
        </li>
    </ol>
</nav>
<div class="card">
    <div class="card-body">
        <h2 class="card-title">Buat Paket</h2>
        <form action="{{ route('paket.store') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="">Nama Paket</label>
                <input type="text" name="nm_paket" required
                    class="form-control {{ $errors->has('nm_paket') ? 'is-invalid':'' }}" autofocus>
                <p class="text-danger">{{ $errors->first('nm_paket') }}</p>
            </div>
            <div class="form-group">
                <label for="">ID Customer</label>
                <input type="text" name="customer_id" required
                    class="form-control {{ $errors->has('customer_id') ? 'is-invalid':'' }}" min="1">
                <p class="text-danger">{{ $errors->first('customer_id') }}</p>
            </div>
            <div class="form-group">
                <label for="">Tujuan</label>
                <input type="text" name="tujuan" required
                    class="form-control {{ $errors->has('tujuan') ? 'is-invalid':'' }}" min="1">
                <p class="text-danger">{{ $errors->first('tujuan') }}</p>
            </div>
            <div class="form-group">
                <label for="">Jam Berangkat</label>
                <input type="text" name="jam_brkt" required
                    class="form-control {{ $errors->has('jam_brkt') ? 'is-invalid':'' }}" min="1">
                <p class="text-danger">{{ $errors->first('jam_brkt') }}</p>
            </div>
            <div class="form-group">
                <label for="">Jam Tiba</label>
                <input type="text" name="jam_tiba" required
                    class="form-control {{ $errors->has('jam_tiba') ? 'is-invalid':'' }}" min="1">
                <p class="text-danger">{{ $errors->first('jam_tiba') }}</p>
            </div>
            <div class="form-group">
                <button class="btn btn-primary btn-sm" style="float: right">
                    <i class="fa fa-send"></i> Save
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
