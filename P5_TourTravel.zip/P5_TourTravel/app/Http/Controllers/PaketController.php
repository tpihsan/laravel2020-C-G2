<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Paket;
use App\Customer;


class PaketController extends Controller
{
    public function index(){
        $pakets = Paket::with('category')->get();
        return view('pages.paket.index', compact('pakets'));
    }

    public function create(){
        $costumers = Customer::all();
        return view('pages.paket.create', compact('customers'));
    }

    public function store(Request $request){
        $this->validate($request,[
            'nm_paket' => 'required',
            'costumer_id' => 'required|exists:customers,id',
            'tujuan' => 'required',
            'jam_brkt' => 'required',
            'jam_tiba' => 'required',
            'harga' => 'required'
        ]);

        $pakets = Paket::create([
            'nm_paket' => $request->nm_paket,
            'customer_id' =>$request->customer_id,
            'tujuan' => $request->tujuan,
            'jam_brkt' => $request->jam_brkt,
            'jam_tiba' => $request->jam_tiba,
            'harga' => $request->harga
        ]);
        
        return redirect()->route('paket.index')->with('success','Data has been created!');
    }

    public function destroy($paket){
        $pakets = Paket::findOrFail($paket);
        $pakets->delete();

        return redirect()->route('paket.index')->with('success','Date has been deleted!');
    }

    public function edit($paket){
        $pakets = Paket::findOrFail($paket);
        $costumers = Customer::all();
        return view('pages.paket.edit', compact('pakets', 'customers'));
    }

    public function update(Request $request, $paket){
        $pakets = Paket::find($paket);
        $this->validate($request,[
            'nm_paket' => 'required',
            'costumer_id' => 'required|exists:customers,id',
            'tujuan' => 'required',
            'jam_brkt' => 'required',
            'jam_tiba' => 'required',
            'harga' => 'required'
        ]);

        $pakets->update([
            'nm_paket' => $request->nm_paket,
            'customer_id' =>$request->customer_id,
            'tujuan' => $request->tujuan,
            'jam_brkt' => $request->jam_brkt,
            'jam_tiba' => $request->jam_tiba,
            'harga' => $request->harga
        ]);

        return redirect()->route('paket.index')->with('success','Data has been updated!');
    }
}
