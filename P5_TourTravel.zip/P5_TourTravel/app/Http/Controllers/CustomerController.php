<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use Alert; 


class CustomerController extends Controller
{
    public function index(){
        $customers = Customer::all();
        return view('pages.customer.index', compact('customers'));
    }

    public function store(Request $request){
        $this->validate($request, [
            'nm_customer' => 'required',
            'alamat' => 'required',
            'notelp' => 'required'
        ]);

        $customers = Customer::create([
            'nm_customer' => $request->nm_customer,
            'alamat' => $request->alamat,
            'notelp' => $request->notelp
        ]);
        return redirect()->route('customer.index')->with('success', 'Data has been created!');
    }

    public function destroy($customer){
        $customers = Customer::findOrFail($customer);

        $customers->delete();
        return redirect()->route('customer.index')->with('success', 'Data has been deleted!');
    }

    public function edit($customer){
        $customers = Customer::find($customer);
        return view('pages.customer.edit', compact('customers'));
    }

    public function update(Request $request, $customer){
        $this->validate($request, [
            'nm_customer' => 'required',
            'alamat' => 'required',
            'notelp' => 'required'
        ]);

        $customers = Customer::findOrFail($customer);

        $customers->update([
            'nm_customer' => $request->nm_customer,
            'alamat' => $request->alamat,
            'notelp' => $request->notelp
        ]);

        return redirect()->route('customer.index')->with('success', 'Data has been updated!');
    }

    
}
