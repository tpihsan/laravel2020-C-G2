<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Paket;

class Customer extends Model
{
    protected $guarded = [];

    public function pakets()
    {
        return $this->hasMany(Paket::class);
    }
}
