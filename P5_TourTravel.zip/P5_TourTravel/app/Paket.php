<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Customer;

class Paket extends Model
{
    protected $guarded = [];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
}
